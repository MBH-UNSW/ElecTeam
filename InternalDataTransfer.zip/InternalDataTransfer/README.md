# InternalDataTransfer

LSK data transmitter for the STM32G431CBT6 Internal Data Transfer PCB.
Generates a random 32-bit word with the RNG and clocks it out on DATA_SCT (PA8)
to switch Q1, loading/unloading the inductor tank. STATUS_LED (PB3) mirrors each bit.

- MCU: STM32G431CBT6 (LQFP48)
- STM32CubeMX 6.13.0, STM32Cube FW_G4 V1.6.1 (HAL V1.2.5, CMSIS Device V1.2.5)
- Toolchain: CMake + Ninja + arm-none-eabi-gcc
- Clock: 24 MHz HSE crystal -> PLL -> 96 MHz SYSCLK, 48 MHz RNG clock
- Bit timing: TIM1 at 1 MHz tick, Period 99 -> 100 us/bit (10 kb/s)

## Pins

| Pin  | Label      | Function                          |
|------|------------|-----------------------------------|
| PA8  | DATA_SCT   | Q1 gate (HIGH = bit 1, Q1 on)     |
| PB3  | STATUS_LED | Mirrors the bit being sent        |
| PA13 | SWDIO      | J3 programming header             |
| PA14 | SWCLK      | J3 programming header             |
| PF0  | OSC_IN     | 24 MHz crystal                    |
| PF1  | OSC_OUT    | 24 MHz crystal                    |

## Settings (top of Core/Src/main.c, USER CODE PD block)

- `DEBUG_SLOW_MODE 1` sends 1 bit per second so you can watch the LED.
- `FRAME_GAP_BITS` sets the idle time between 32-bit frames.
- To change the bit rate, change TIM1 Period in CubeMX (Period + 1 = bit time in us)
  and update `DATA_RATE_BPS` to match.

## Build

From this folder:

```
cmake --preset Debug
cmake --build --preset Debug
```

Output: `build/Debug/InternalDataTransfer.elf` (+ `.hex` and `.bin`).
Flash with STM32CubeProgrammer over SWD (J3), or open the folder in VS Code
with the STM32 extension, or import it into STM32CubeIDE.

## Fault indication

If the HSE crystal does not start or the RNG fails, `Error_Handler()` turns
Q1 off and leaves the status LED solid on.
